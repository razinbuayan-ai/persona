(function(){
var songs=[["Color Your Night","music/color-your-night.mp3"],["I Will Protect You -Reload-","music/i-will-protect-you-reload.mp3"],["Memories of You -Reload-","music/memories-of-you-reload.mp3"],["Joy - P3R ver.","music/joy-p3r.mp3"]];
var K="razinPlayer",st={i:0,t:0,on:false};
try{st=Object.assign(st,JSON.parse(localStorage.getItem(K)||"{}"))}catch(e){}
if(!(st.i>=0&&st.i<songs.length))st.i=0;
var bar=document.createElement("div");bar.id="bar";bar.setAttribute("role","region");bar.setAttribute("aria-label","Music player");
bar.innerHTML='<div id="tl" hidden><h4>Track Select</h4><ol>'+songs.map(function(s,k){return '<li><button type="button" data-i="'+k+'"><b>0'+(k+1)+'</b><span>'+s[0]+'</span></button></li>'}).join("")+'</ol></div>'
+'<div class="disc" aria-hidden="true"></div><div class="np"><span class="tag">Now Playing</span><span class="title" aria-live="polite"></span></div>'
+'<div class="eq" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></div>'
+'<div class="ctrl"><button type="button" class="prev" aria-label="Previous song">&#9664;&#9664;</button><button type="button" class="play" aria-label="Play">&#9654;</button><button type="button" class="next" aria-label="Next song">&#9654;&#9654;</button><button type="button" class="list" aria-expanded="false" aria-controls="tl">Tracks</button></div>'
+'<div class="seekwrap"><span class="cur">0:00</span><input type="range" class="seek" min="0" max="100" step="0.1" value="0" aria-label="Seek"><span class="dur">0:00</span></div><p class="msg" role="status"></p>';
document.body.appendChild(bar);
var a=new Audio(),q=function(s){return bar.querySelector(s)},play=q(".play"),seek=q(".seek"),cur=q(".cur"),dur=q(".dur"),msg=q(".msg"),title=q(".title"),tl=q("#tl"),lb=q(".list"),tb=[].slice.call(tl.querySelectorAll("button")),i=st.i;
a.preload="none";
function t(s){s=Math.floor(s||0);return Math.floor(s/60)+":"+("0"+s%60).slice(-2)}
function save(){try{localStorage.setItem(K,JSON.stringify({i:i,t:a.currentTime||0,on:!a.paused}))}catch(e){}}
function prog(v){seek.value=v;seek.style.setProperty("--p",v+"%")}
function load(n,go,at){i=(n+songs.length)%songs.length;msg.textContent="";prog(0);cur.textContent="0:00";dur.textContent="0:00";
 title.textContent=songs[i][0];tb.forEach(function(b,k){b.classList.toggle("on",k===i)});
 a.src=songs[i][1];if(at){a.addEventListener("loadedmetadata",function f(){a.currentTime=at;a.removeEventListener("loadedmetadata",f)})}
 if(go)a.play().catch(function(){});save()}
function openList(o){tl.hidden=!o;lb.setAttribute("aria-expanded",o);lb.classList.toggle("open",o)}
play.onclick=function(){if(!a.src)load(i,true);else if(a.paused)a.play().catch(function(){});else a.pause()};
q(".next").onclick=function(){load(i+1,true)};q(".prev").onclick=function(){load(i-1,true)};
lb.onclick=function(e){e.stopPropagation();openList(tl.hidden)};
tb.forEach(function(b){b.onclick=function(){load(+b.dataset.i,true);openList(false)}});
document.addEventListener("click",function(e){if(!tl.hidden&&!bar.contains(e.target))openList(false)});
document.addEventListener("keydown",function(e){if(e.key==="Escape"&&!tl.hidden){openList(false);lb.focus()}});
a.onplay=function(){play.innerHTML="&#10074;&#10074;";play.setAttribute("aria-label","Pause");bar.classList.add("playing");save()};
a.onpause=function(){play.innerHTML="&#9654;";play.setAttribute("aria-label","Play");bar.classList.remove("playing");save()};
a.onended=function(){load(i+1,true)};
a.onloadedmetadata=function(){dur.textContent=t(a.duration)};
a.ontimeupdate=function(){cur.textContent=t(a.currentTime);if(a.duration)prog(a.currentTime/a.duration*100)};
seek.oninput=function(){if(a.duration){a.currentTime=seek.value/100*a.duration}prog(seek.value)};
a.onerror=function(){bar.classList.remove("playing");play.innerHTML="&#9654;";play.setAttribute("aria-label","Play");msg.textContent="File not found. Add "+songs[i][1]+" to the music folder."};
window.addEventListener("pagehide",save);setInterval(function(){if(!a.paused)save()},1500);
window.razinPlay=function(){if(a.paused)play.click()};
load(i,st.on,st.t);
})();

(function(){
var d=document,ro=matchMedia("(prefers-reduced-motion:reduce)").matches;
/* Moon phase background */
var cyc=29.530588,p=((((Date.now()-Date.UTC(2000,0,6,18,14))/864e5)%cyc)+cyc)%cyc/cyc;
var names=["New Moon","Waxing Crescent","First Quarter","Waxing Gibbous","Full Moon","Waning Gibbous","Last Quarter","Waning Crescent"],pn=names[Math.floor(p*8+.5)%8];
var q=p<.5?p:1-p,k=Math.cos(2*Math.PI*q),rx=Math.abs(k)*50;
var m=d.createElement("div");m.id="moon";m.setAttribute("aria-hidden","true");
m.innerHTML='<svg viewBox="-2 -2 104 104"><circle cx="50" cy="50" r="50" fill="#0a1d3d" opacity=".6"/><path'+(p<.5?'':' transform="translate(100 0) scale(-1 1)"')+' d="M50 0A50 50 0 0 1 50 100A'+rx+' 50 0 0 '+(k>0?0:1)+' 50 0z" fill="#dff6ff"/></svg>';
d.body.appendChild(m);
/* In-game clock */
var nav=d.querySelector("nav"),c=d.createElement("div");c.id="clock";c.innerHTML='<span class="ct"></span><span class="cd"></span><span class="cm"></span>';nav.appendChild(c);
function tick(){var n=new Date(),dh=n.getHours()===0;d.body.classList.toggle("darkhour",dh);
 c.querySelector(".ct").textContent=n.toLocaleTimeString("en-US",{hour:"numeric",minute:"2-digit"});
 c.querySelector(".cd").textContent=n.toLocaleDateString("en-US",{weekday:"short"}).toUpperCase()+" "+(n.getMonth()+1)+"/"+n.getDate();
 c.querySelector(".cm").textContent=dh?"DARK HOUR":pn}
tick();setInterval(tick,1000);
/* Views and transitions */
var ids=["home","about","skills","projects","achievements","contact"],titles={home:"Home",about:"About Me",skills:"My Skills",projects:"My Projects",achievements:"Achievements and Awards",contact:"Contact and Social Media"},views=[].slice.call(d.querySelectorAll(".page")),links=[].slice.call(d.querySelectorAll("nav a")),w=d.getElementById("wipe"),it=d.getElementById("intro"),de=d.documentElement,cur="",busy=false,entering=false;
if(ro&&w){w.remove();w=null}
addEventListener("pageshow",function(e){if(e.persisted&&w)w.className="out"});
function reveal(){if(w)requestAnimationFrame(function(){requestAnimationFrame(function(){w.className="out";busy=false})});else busy=false}
function show(){var h=location.hash.slice(1);if(ids.indexOf(h)<0)h="home";cur=h;
 views.forEach(function(v){v.classList.toggle("active",v.id==="pg-"+h)});
 links.forEach(function(x){if(x.getAttribute("href")==="#"+h)x.setAttribute("aria-current","page");else x.removeAttribute("aria-current")});
 d.title=titles[h]+" | Razin Ali Buayan";scrollTo(0,0);reveal()}
addEventListener("hashchange",show);
d.addEventListener("click",function(e){var a=e.target.closest&&e.target.closest("a");if(!a)return;var h=a.getAttribute("href")||"";
 if(h.charAt(0)!=="#"||e.ctrlKey||e.metaKey||e.shiftKey)return;var id=h.slice(1);if(ids.indexOf(id)<0)return;
 e.preventDefault();if(id===cur||busy)return;busy=true;
 if(w){w.className="in";setTimeout(function(){location.hash=id},560)}else location.hash=id});
/* Intro screen */
function finish(){if(!it)return;it.remove();it=null;de.classList.remove("lock");
 var v=d.querySelector(".page.active");if(v){v.classList.remove("active");void v.offsetWidth;v.classList.add("active")}
 reveal()}
function go(){if(entering)return;entering=true;
 try{sessionStorage.setItem("entered","1")}catch(e){}
 if(window.razinPlay)window.razinPlay();
 if(w){w.className="in";setTimeout(finish,560)}else finish()}
if(it){if(de.className==="entered"){it.remove();it=null}else{
 d.getElementById("enter").addEventListener("click",go);
 d.addEventListener("keydown",function(e){if(e.key==="Enter"&&it){e.preventDefault();go()}})}}
show();
})();

